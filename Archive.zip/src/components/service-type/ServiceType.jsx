import "./ServiceType.scss";

const ServiceType = () => {
    return (
        <div className="service-type">
            <h2 className="service-type__title title">About Us</h2>
            <span className="service-type__sub-title">
                Fresh Flowers Aroma Shop
            </span>
        </div>
    );
};

export default ServiceType;
